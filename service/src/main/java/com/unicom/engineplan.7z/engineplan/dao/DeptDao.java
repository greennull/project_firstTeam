package com.unicom.engineplan.dao;
import java.util.List;

import com.unicom.engineplan.model.Dept;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface DeptDao {
    @Select("select * from dept")
    List<Dept> getAllDept();

    /**
     * 删除操作
     */
    @Delete("delete from dept where id = #{id}")
    int delDept(int id);
    /**
     * 修改操作
     */
    @Update("UPDATE dept SET deptName = #{deptName} WHERE id = #{id} ")
    int updateDept(int id);
}
